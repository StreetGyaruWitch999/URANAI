#ifndef NewThermal_h

#define NewThermal_h

#include <Arduino.h>
#include <SoftwareSerial.h>

class NewThermal : public SoftwareSerial
{

  public:
    NewThermal(int, int, long); // constructor
    void setDefault();
	
	void printJapanese(const char *st);
	void printlnJapanese(const char *st);
	void printJapanese(const String &s);
	void printlnJapanese(const String &s);
	void printJapanese(const char *st, const bool lnFlag);

	String alignConcatStr(const String& inputStr1, const String& inputStr2, int size);
	void printlnAlignConcatStr(const char *st1, const char *st2, int size);
	void printAlignConcatStr(const char *st1, const char *st2, int size);
	void printlnAlignConcatStr(const String& inputStr1, const String& inputStr2, int size);
	void printAlignConcatStr(const String& inputStr1, const String& inputStr2, int size);

	uint16_t getEuc(uint32_t src_unicode);
	uint16_t getEucForSpecial(uint32_t src_unicode);
	size_t UTF8_to_SJIS_str_cnv(const uint8_t* strUTF8, uint8_t* sjis_byte);

    void doubleHeightOn();
    void doubleHeightOff();
    void doubleWidthOn();
    void doubleWidthOff();
    void boldOn();
    void boldOff();
    void underline1On();
    void underline2On();
    void underlineOff();
    void inverseOn();
    void inverseOff();
	
    void justify(char value);
    void feed(uint8_t x = 1);
    void sleep();
    void wake();
    void setSize(char value);
    void setLineHeight(int val = 32);

    void printBarcode(char * text);
    void printCode93Barcode(char * text);
    void setBarcodeHeight(int val);

    void printBitmap(uint8_t w, uint8_t h,  const uint8_t *bitmap);

    void writeBytes(uint8_t a, uint8_t b);
    void writeBytes(uint8_t a, uint8_t b, uint8_t c);
    void writeBytes(uint8_t a, uint8_t b, uint8_t c, uint8_t d);
	
  private:
    boolean linefeedneeded;

    int zero;
    int heatTime;
    int heatInterval;
    char printDensity;
    char printBreakTime;
};

#endif
