#include <Arduino.h>
#include <NewThermal.h>

static const struct {
    uint32_t unicode;
	uint16_t sjis;
} table[] = {
	//　、。，．：；？！゛゜｀¨
    { 0xE38080, 0xA1A1 },
    { 0xE38081, 0xA1A2 },
    { 0xE38082, 0xA1A3 },
    { 0xEFBC8C, 0xA3AC },
    { 0xEFBC8E, 0xA3AE },
    { 0xEFBC9A, 0xA3BA },
    { 0xEFBC9B, 0xA3BB },
    { 0xEFBC9F, 0xA3BF },
    { 0xEFBC81, 0xA3A1 },
    { 0xE3829B, 0xA961 },
    { 0xE3829C, 0xA962 },
    { 0xEFBD80, 0xA3E0 },
    { 0xC2A800, 0xA1A7 },

	//＾￣＿ヽヾゝゞ〃仝々〆〇ー―‐
    { 0xEFBCBE, 0xA3DE },
    { 0xEFBFA3, 0xA3FE },
    { 0xEFBCBF, 0xA3DF },
    { 0xE383BD, 0xA963 },
    { 0xE383BE, 0xA964 },
    { 0xE3829D, 0xA966 },
    { 0xE3829E, 0xA967 },
    { 0xE38083, 0xA1A8 },
    { 0xE4BB9D, 0xD9DA },
    { 0xE38085, 0xA1A9 },
    { 0xE38086, 0xA965 },
    { 0xE38087, 0xA996 },
    { 0xE383BC, 0xA960 },
    { 0xE28095, 0xA844 },
    { 0xE28090, 0xA95C },

	//／＼～∥｜…‥‘’“”（）〔〕
    { 0xEFBC8F, 0xA3AF },
    { 0xEFBCBC, 0xA3DC },
    { 0xEFBD9E, 0xA1AB },
    { 0xE288A5, 0xA1CE },
    { 0xEFBD9C, 0xA3FC },
    { 0xE280A6, 0xA1AD },
    { 0xE280A5, 0xA845 },
    { 0xE28098, 0xA1AE },
    { 0xE28099, 0xA1AF },
    { 0xE2809C, 0xA1B0 },
    { 0xE2809D, 0xA1B1 },
    { 0xEFBC88, 0xA3A8 },
    { 0xEFBC89, 0xA3A9 },
    { 0xE38094, 0xA1B2 },
    { 0xE38095, 0xA1B3 },

	//［］｛｝〈〉《》「」『』【】＋
    { 0xEFBCBB, 0xA3DB },
    { 0xEFBCBD, 0xA3DD },
    { 0xEFBD9B, 0xA3FB },
    { 0xEFBD9D, 0xA3FD },
    { 0xE38088, 0xA1B4 },
    { 0xE38089, 0xA1B5 },
    { 0xE3808A, 0xA1B6 },
    { 0xE3808B, 0xA1B7 },
    { 0xE3808C, 0xA1B8 },
    { 0xE3808D, 0xA1B9 },
    { 0xE3808E, 0xA1BA },
    { 0xE3808F, 0xA1BB },
    { 0xE38090, 0xA1BE },
    { 0xE38091, 0xA1BF },
    { 0xEFBC8B, 0xA3AB },

	//－±×÷＝≠＜＞≦≧∞∴♂♀°
    { 0xEFBC8D, 0xA3AD },
    { 0xC2B1  , 0xA1C0 },
    { 0xC397  , 0xA1C1 },
    { 0xC3B7  , 0xA1C2 },
    { 0xEFBC9D, 0xA3BD },
    { 0xE289A0, 0xA1D9 },
    { 0xEFBC9C, 0xA3BC },
    { 0xEFBC9E, 0xA3BE },
    { 0xE289A6, 0xA851 },
    { 0xE289A7, 0xA852 },
    { 0xE2889E, 0xA1DE },
    { 0xE288B4, 0xA1E0 },
    { 0xE29982, 0xA1E1 },
    { 0xE29980, 0xA1E2 },
    { 0xC2B0  , 0xA1E3 },

	//′″℃￥＄￠￡％＃＆＊＠§☆★
    { 0xE280B2, 0xA1E4 },
    { 0xE280B3, 0xA1E5 },
    { 0xE28483, 0xA1E6 },
    { 0xEFBFA5, 0xA3A4 },
    { 0xEFBC84, 0xA1E7 },
    { 0xEFBFA0, 0xA1E9 },
    { 0xEFBFA1, 0xA1EA },
    { 0xEFBC85, 0xA3A5 },
    { 0xEFBC83, 0xA3A3 },
    { 0xEFBC86, 0xA3A6 },
    { 0xEFBC8A, 0xA3AA },
    { 0xEFBCA0, 0xA3C0 },
    { 0xC2A7  , 0xA1EC },
    { 0xE29886, 0xA1EE },
    { 0xE29885, 0xA1EF },

	//○●◎◇字◆□■△▲▽▼※〒→←↑↓〓
    { 0xE2978B, 0xA1F0 },
    { 0xE2978F, 0xA1F1 },
    { 0xE2978E, 0xA1F2 },
    { 0xE29787, 0xA1F3 },
    { 0xE5AD97, 0xD7D6 },
    { 0xE29786, 0xA1F4 },
    { 0xE296A1, 0xA1F5 },
    { 0xE296A0, 0xA1F6 },
    { 0xE296B3, 0xA1F7 },
    { 0xE296B2, 0xA1F8 },
    { 0xE296BD, 0xA88C },
    { 0xE296BC, 0xA88B },
    { 0xE280BB, 0xA1F9 },
    { 0xE38092, 0xA893 },
    { 0xE28692, 0xA1FA },
    { 0xE28690, 0xA1FB },
    { 0xE28691, 0xA1FC },
    { 0xE28693, 0xA1FD },
    { 0xE38093, 0xA1FE }
};

NewThermal::NewThermal(int RX_Pin, int TX_Pin, long baudRate) : SoftwareSerial(RX_Pin, TX_Pin)
{
	pinMode(RX_Pin, INPUT);
	pinMode(TX_Pin, OUTPUT);

	begin(baudRate);

	setDefault();
}

void NewThermal::setDefault()
{
	doubleHeightOff();
	doubleWidthOff();
	boldOff();
	underlineOff();
	inverseOff();
	
	setLineHeight(32);
	setBarcodeHeight(50);

	justify('L');
	setSize('s');
	
	//writeBytes(28, 46);
	//writeBytes(27, 116, 1);
}


void NewThermal::writeBytes(uint8_t a, uint8_t b)
{
	write(a);
	write(b);
}

void NewThermal::writeBytes(uint8_t a, uint8_t b, uint8_t c)
{
	write(a);
	write(b);
	write(c);
}

void NewThermal::writeBytes(uint8_t a, uint8_t b, uint8_t c, uint8_t d)
{
	write(a);
	write(b);
	write(c);
	write(d);
}


void NewThermal::printlnAlignConcatStr(const char *st1, const char *st2, int size)
{
	printAlignConcatStr(st1, st2, size);
	println("");
}

void NewThermal::printAlignConcatStr(const char *st1, const char *st2, int size)
{
	int i;
	
	char sjis_byte1[(strlen(st1) * 2) + 1];

	size_t sj_length1 = UTF8_to_SJIS_str_cnv(st1, sjis_byte1);
	
	char sjis_byte2[(strlen(st2) * 2) + 1];

	size_t sj_length2 = UTF8_to_SJIS_str_cnv(st2, sjis_byte2);

	//println("1>" + String(sj_length1));
	//println("2>" + String(sj_length2));

    int spaceSize = size - sj_length1 - sj_length2;

    if(spaceSize > 0)
    {
		print(sjis_byte1);

        for(i = 0; i < spaceSize; i++)
        {
			print(" ");
        }

    	print(sjis_byte2);
    }
    else
    {
        if(size <= sj_length1)
        {
			for(i = 0; i < size; i++)
			{
				print(*sjis_byte1);
				sjis_byte1[i];
			}
        }
        else
        {
			print(sjis_byte1);
			for(i = 0; i < (size - sj_length1); i++)
			{
				print(*sjis_byte2);
				sjis_byte2[i];
			}
        }
    }
}

void NewThermal::printlnAlignConcatStr(const String& inputStr1, const String& inputStr2, int size)
{
	printAlignConcatStr(inputStr1, inputStr2, size);
	println("");
}

void NewThermal::printAlignConcatStr(const String& inputStr1, const String& inputStr2, int size)
{
	const char *st1 = inputStr1.c_str();
	const char *st2 = inputStr2.c_str();
	printlnAlignConcatStr(st1, st2, size);
}

void NewThermal::setBarcodeHeight(int val)
{
	// default is 50
	writeBytes(29, 104, val);
}

void NewThermal::printBarcode(char * text){
  writeBytes(29, 107, 0); // GS, K, m!
  
  for(int i = 0; i < strlen(text); i ++){
    write(text[i]); //Data
  }
 
  write(zero); //Terminator
  
  delay(3000); //For some reason we can't immediately have line feeds here
  feed(2);
}

void NewThermal::printCode93Barcode(char * text){
  int len = strlen(text);
  writeBytes(29, 107, 72, len); // GS, K, Fancy!
  
  for(int i = 0; i < len; i ++){
    write(text[i]); //Data
  }
 
  write(zero); //Terminator
  
  delay(3000); //For some reason we can't immediately have line feeds here
  feed(2);
}

void NewThermal::doubleHeightOn()
{
	writeBytes(27, 33, 16);
}

void NewThermal::doubleHeightOff()
{
	writeBytes(27, 33, 0);
}

void NewThermal::doubleWidthOn()
{
	writeBytes(27, 14);
}

void NewThermal::doubleWidthOff()
{
	writeBytes(27, 20);
}

void NewThermal::boldOn()
{
	writeBytes(27, 69, 1);
}

void NewThermal::boldOff()
{
	writeBytes(27, 69, 0);
}

void NewThermal::underline1On()
{
	writeBytes(27, 45, 1);
}

void NewThermal::underline2On()
{
	writeBytes(27, 45, 2);
}

void NewThermal::underlineOff()
{
	writeBytes(27, 45, 0);
}

void NewThermal::inverseOn()
{
	writeBytes(29, 66, 1);
}

void NewThermal::inverseOff()
{
	writeBytes(29, 66, 0);
}

void NewThermal::justify(char value)
{
	uint8_t pos = 0;

	if(value == 'l' || value == 'L') pos = 0;
	if(value == 'c' || value == 'C') pos = 1;
	if(value == 'r' || value == 'R') pos = 2;
  
	writeBytes(0x1B, 0x61, pos);
}

void NewThermal::feed(uint8_t x)
{
	while (x--)
		write(10);
}

void NewThermal::setSize(char value)
{
	int size = 0;

	if(value == 's' || value == 'S') size = 0;
	if(value == 'm' || value == 'M') size = 10;
	if(value == 'l' || value == 'L') size = 25;
  
	writeBytes(29, 33, size, 10);
	// if (linefeedneeded)
	//  println("lfn"); //feed();
	//linefeedneeded = false;
}

void NewThermal::printBitmap(uint8_t w, uint8_t h,  const uint8_t *bitmap)
{
	writeBytes(18, 42, h, w/8);
	for (uint16_t i=0; i<(w/8) * h; i++) {
		write(pgm_read_byte(bitmap + i));
	}
}

void NewThermal::wake()
{
	writeBytes(27, 61, 1);
}

void NewThermal::sleep()
{
	writeBytes(27, 61, 0);
}

void NewThermal::setLineHeight(int val)
{
	writeBytes(27, 51, val); // default is 32
}

void NewThermal::printJapanese(const char *st) {

	printJapanese(st, false);
}

void NewThermal::printlnJapanese(const char *st) {

	printJapanese(st, true);
}

void NewThermal::printJapanese(const String &s) {
	printJapanese(s.c_str(), false);
}

void NewThermal::printlnJapanese(const String &s) {
	printJapanese(s.c_str(), true);
}

void NewThermal::printJapanese(const char *st, const bool lnFlag) {

	char sjis_byte[(strlen(st) * 2) + 1];

	size_t sj_length = UTF8_to_SJIS_str_cnv(st, sjis_byte);

	if (lnFlag) {
		println(sjis_byte);
	} else {
		print(sjis_byte);
	}
}

uint16_t NewThermal::getEuc(uint32_t src_unicode)
{
	int gap = 0;
	uint16_t result = 0;
	
	if ((src_unicode >= 0xE38181) && (src_unicode <= 0xE381BF)) {
		gap = src_unicode - 0xE38181;
		result = 0xA4A1 + gap;
	} else if ((src_unicode >= 0xE38280) && (src_unicode <= 0xE38293)) {
		gap = src_unicode - 0xE38280;
		result = 0xA4E0 + gap;
	} else if ((src_unicode >= 0xE382A1) && (src_unicode <= 0xE382BF)) {
		gap = src_unicode - 0xE382A1;
		result = 0xA5A1 + gap;
	} else if ((src_unicode >= 0xE38380) && (src_unicode <= 0xE383B6)) {
		gap = src_unicode - 0xE38380;
		result = 0xA5C0 + gap;
	} else {
		result = getEucForSpecial(src_unicode);
	}

	//print("@");
	//println(result, HEX);

    return result;
}

uint16_t NewThermal::getEucForSpecial(uint32_t src_unicode)
{
    int i;
    for (i = 0; table[i].unicode; ++i) {

        if (src_unicode == table[i].unicode) {
            return table[i].sjis;
        }

    }
	
	//print("@@");
	//println(src_unicode, HEX);
	
    return src_unicode;
}

size_t NewThermal::UTF8_to_SJIS_str_cnv(const uint8_t* strUTF8, uint8_t* sjis_byte) {
	
	size_t sj_cnt = 0;
	uint32_t SJ;
	uint16_t SS;

	while(*strUTF8){

		if ((*strUTF8==0xE2) || 
			(*strUTF8==0xE3) || 
			(*strUTF8==0xE3) || 
			(*strUTF8==0xE5) || 
			(*strUTF8==0xEF) || 
			(*strUTF8==0xC2) || 
			(*strUTF8==0xC3)) {
			SJ = 0;
			SJ += *strUTF8;
			if ((*strUTF8 == 0xC2) || (*strUTF8 == 0xC3)) {
				SJ = SJ << 8;
				strUTF8++;
				SJ += *strUTF8;
			} else {
				SJ = SJ << 8;
				strUTF8++;
				SJ += *strUTF8;
				if (*(strUTF8+1) != 0) {
					SJ = SJ << 8;
					strUTF8++;
					SJ += *strUTF8;
				}
			}
			
			//print("##");
			//println(SJ, HEX);
			
			SS = getEuc(SJ);
			
			sjis_byte[sj_cnt] = SS >> 8;
			
			sj_cnt = sj_cnt + 1;
			
			sjis_byte[sj_cnt] = SS;

			sj_cnt = sj_cnt + 1;

			strUTF8 = strUTF8 + 1;

		} else { //その他は全て半角スペースとする。
			
			//print(">>>");
			//println((unsigned char)*strUTF8, HEX);

			sjis_byte[sj_cnt] = *strUTF8;
			sj_cnt++;
			strUTF8++;
		}
	}

	sjis_byte[sj_cnt] = '\0';

	return sj_cnt;
}

